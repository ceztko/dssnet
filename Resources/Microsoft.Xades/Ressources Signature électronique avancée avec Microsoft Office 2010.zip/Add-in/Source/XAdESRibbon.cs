﻿// Ribbon1.cs
//
// Advanced Digital Signature (XAdES) Configuration Add-in for Microsoft Office Word 2010
// 2010 Microsoft France
// Published under the CECILL-B Free Software license agreement.
// (http://www.cecill.info/licences/Licence_CeCILL-B_V1-en.txt)
// 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
// THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION WITH THE USE OF THIS CODE 
// AND INFORMATION REMAINS WITH THE USER. 
//

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Office = Microsoft.Office.Core;

using Microsoft.Win32;

// TODO:  Follow these steps to enable the Ribbon (XML) item:

// 1: Copy the following code block into the ThisAddin, ThisWorkbook, or ThisDocument class.

//  protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
//  {
//      return new Ribbon();
//  }

// 2. Create callback methods in the "Ribbon Callbacks" region of this class to handle user
//    actions, such as clicking a button. Note: if you have exported this Ribbon from the Ribbon designer,
//    move your code from the event handlers to the callback methods and modify the code to work with the
//    Ribbon extensibility (RibbonX) programming model.

// 3. Assign attributes to the control tags in the Ribbon XML file to identify the appropriate callback methods in your code.  

// For more information, see the Ribbon XML documentation in the Visual Studio Tools for Office Help.

namespace XAdESAddIn
{    
    [ComVisible(true)]
    public class XAdESRibbon : Office.IRibbonExtensibility
    {
        private Office.IRibbonUI ribbon;
        private XAdESProperties m_properties = new XAdESProperties();

        private string m_regKey = @"Software\Microsoft\Office\14.0\Common\Signatures";

        private string[] m_requestedXAdESLevel = {
                    "Aucun niveau XAdES", "XAdES-BES/EPES", "XAdES-T", "XAdES-C", "XAdES-X", "XAdES-X-L" };

        private string[] m_xAdESlevelDescription = {
                    "XML-DSIG : signature simple.", 
                    "XAdES-BES/EPES : forme de base répondant juste à des exigences légales directives pour la signature avancée. Ceci correspond au format par défaut pour les signatures Office 2010.", 
                    "XAdES-T (horodateur) : ajoute le champ d'horodateur pour se protéger contre la répudiation sur les portions XML-DSIG et XAdES-BES/EPES de la signature. La signature est protégée contre l'expiration.", 
                    "XAdES-C (complet) : ajoute des références aux données de vérification (certificats et listes de révocation) aux documents signés pour permettre la vérification en mode déconnecté et la vérification à l'avenir (mais ne stocke pas les données réelles).", 
                    "XAdES-X (prolongé) : ajoute des horodateurs sur les références présentées par XAdES-C pour se protéger contre le compromis possible à l’avenir des certificats dans la chaîne. Les horodateurs additionnels protègent les données additionnelles de la répudiation.", 
                    "XAdES-X-L (terme prolongé) : ajoute les certificats et les listes réels de révocation au document signé pour permettre la vérification à l'avenir même si leur source originale n'est pas disponible." };

        private string[] m_minimumXAdESLevel = {
                    "Aucun niveau minimal", "XAdES-BES/EPES", "XAdES-T", "XAdES-C", "XAdES-X", "XAdES-X-L" };
        
        private string[] m_signatureVerificationLevel = {
                    "Aucune règle", "Règles Office 2007", "Règles Office 2010" };

        private string[] m_digitalSignatureHashingAlgorithm = {
                    "sha1", "sha256", "sha384", "sha512"};

        private bool m_newSettings = false;

        public XAdESRibbon(){}

        #region IRibbonExtensibility Members

        public string GetCustomUI(string ribbonID)
        {
            return GetResourceText("XAdESAddIn.XAdESRibbon.xml");
        }

        #endregion

        #region Ribbon Callbacks
        //Create callback methods here. For more information about adding callback methods, select the Ribbon XML item in Solution Explorer and then press F1

        public void Ribbon_Load(Office.IRibbonUI ribbonUI)
        {
            this.ribbon = ribbonUI;

            // Retrieves XAdES settings from the Registry
            RetrieveXAdESSettingsFromRegistry();
        }

        public string GetLabel(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                case "AdvancedSignature":
                    return "Signature avancée";
                // Signature Generation settings 
                case "SignatureGeneration":
                    return "Génération des signatures";
                case "Revert2DefaultSignatureGeneration":
                    return "Restaurer les valeurs par défaut";
                case "RequireOCSPAtSignature":
                    return "Exiger le protocole OCSP au moment de la génération des signatures";
                case "RequestedXAdESLevel":
                    return "Niveau XAdES demandé pour la génération des signatures :";
                case "RequestedXAdESLevelDescription":
                    return m_xAdESlevelDescription[m_properties.XAdESLevel];
                case "MinimumXAdESLevel":
                    return "Niveau XAdES minimal pour la génération des signatures numériques :";
                case "DoNotIncludeXAdESReferenceObjectInTheManifest":
                    return "Ne pas inclure d’objet de référence XAdES dans le manifeste";
                case "TimestampServerName":
                    return "URL du serveur d’horodatage :";
                case "TimestampServerTimeout":
                    return "Délai d’expiration du serveur d’horodatage (en secondes) :";
                case "TimeStampingHashingAlgorithm":
                    return "Algorithme de hachage d’horodatage :";
                // Signature Verification settings
                case "SignatureVerification":
                    return "Vérification des signatures";
                case "Revert2DefaultSignatureVerification":
                    return "Restaurer les valeurs par défaut";
                case "SignatureVerificationLevel":
                    return "Niveau de vérification de signature :";
                case "DigitalSignatureHashingAlgorithm":
                    return "Algorithme de hachage de signature numérique :";
                case "DoNotAllowExpiredCertificates":
                    return "Ne pas autoriser les certificats arrivés à expiration lors de la validation des signatures";
                case "CheckTheXAdESPortionsOfADigitalSignature":
                    return "Vérifier les parties XAdES d’une signature numérique";
                // Other settings
                case "RestartNotificationDescription":
                    return (true == m_newSettings) ? "Les paramètres ci-contre seront pris en compte lors du prochain démarrage de Microsoft Word 2010" : "";
                default:
                    return String.Empty;
            }
        }

        public System.Drawing.Bitmap GetImage(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                case "Revert2DefaultSignatureGeneration":
                case "Revert2DefaultSignatureVerification":
                    return Properties.Resources.Revert;
                default:
                    return null;
            }
        }

        public string GetHelperText(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "SignatureGeneration":
                    return "Génération des signatures pour les documents Word avec le paramétrage suivant :";
                // Signature Verification settings
                case "SignatureVerification":
                    return "Vérification des signatures pour les documents Word avec le paramétrage suivant :";
                // Other settings
                default:
                    return String.Empty;
            }
        }

        public int GetItemCount(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "RequestedXAdESLevel":
                case "MinimumXAdESLevel":
                    return 6;
                case "TimeStampingHashingAlgorithm":
                    return 4;
                // Signature Verification settings 
                case "SignatureVerificationLevel":
                    return 3;
                case "DigitalSignatureHashingAlgorithm":
                    return 4;
                // Other settings
                default:
                    return 0;
            }
        }

        public string GetItemLabel(Office.IRibbonControl control, int index)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "RequestedXAdESLevel":
                    return ((-1 != index) ? m_requestedXAdESLevel[index] : m_requestedXAdESLevel[0]);
                case "MinimumXAdESLevel":
                    return ((-1 != index) ? m_minimumXAdESLevel[index] : m_minimumXAdESLevel[0]);
                case "TimeStampingHashingAlgorithm":
                    return ((-1 != index) ? m_digitalSignatureHashingAlgorithm[index] : m_digitalSignatureHashingAlgorithm[0]);
                // Signature Verification settings 
                case "SignatureVerificationLevel":
                    return ((-1 != index) ? m_signatureVerificationLevel[index] : m_signatureVerificationLevel[0]);
                case "DigitalSignatureHashingAlgorithm":
                    return ((-1 != index) ? m_digitalSignatureHashingAlgorithm[index] : m_digitalSignatureHashingAlgorithm[0]);
                // Other settings
                default:
                    return String.Empty;
            }
        }

        public string GetItemID(Office.IRibbonControl control, int index)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "RequestedXAdESLevel":
                case "MinimumXAdESLevel":
                case "TimeStampingHashingAlgorithm":
                // Signature Verification settings 
                case "SignatureVerificationLevel":
                case "DigitalSignatureHashingAlgorithm":
                    return control.Id + index;
                // Other settings
                default:
                    return String.Empty;
            }
        }

        public int GetSelectedItemIndex(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "RequestedXAdESLevel":
                    return m_properties.XAdESLevel;
                case "MinimumXAdESLevel":
                    return m_properties.MinXAdESLevel;
                case "TimeStampingHashingAlgorithm":
                    for (int i=0; i < 4; i++)
                    {
                        if (0 == String.Compare(m_properties.TimestampHashAlg, m_digitalSignatureHashingAlgorithm[i], true, CultureInfo.InvariantCulture))
                        { return i; }
                    }

                    return 0;

                // Signature Verification settings
                case "SignatureVerificationLevel":
                    return m_properties.VerifyVersion;
                case "DigitalSignatureHashingAlgorithm":
                    for (int i=0; i < 4; i++)
                    {
                        if (0 == String.Compare(m_properties.SignatureHashAlg, m_digitalSignatureHashingAlgorithm[i], true, CultureInfo.InvariantCulture))
                        { return i; }
                    }

                    return 0;

                // Other settings
                default:
                    return -1;
            }
        }

        public bool GetPressed(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "RequireOCSPAtSignature":
                    return m_properties.RequireOCSP;
                case "DoNotIncludeXAdESReferenceObjectInTheManifest":
                    return m_properties.O12CompatibleXAdES;
                // Signature Verification settings
                case "DoNotAllowExpiredCertificates":
                    return m_properties.IgnoreExpiredCert;
                case "CheckTheXAdESPortionsOfADigitalSignature":
                    return m_properties.XAdESValidationLevel;
                // Other settings
                default:
                    return false;
            }
        }

        public void OnClick(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "Revert2DefaultSignatureGeneration":
                    RevertXAdESSettings2Default();

                    break;
                // Signature Verification settings
                case "Revert2DefaultSignatureVerification":
                    RevertXAdESSettings2Default();

                    break;
                // Other settings
                default:
                    break;
            }
        }

        public void OnAction(Office.IRibbonControl control, bool value)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "RequireOCSPAtSignature":
                    m_properties.RequireOCSP = value;
                    WriteRegistryValue("RequireOCSP", (m_properties.RequireOCSP) ? 1 : 0);

                    m_newSettings = true;
                    this.ribbon.InvalidateControl("RestartNotificationDescription");

                    break;
                case "DoNotIncludeXAdESReferenceObjectInTheManifest":
                    m_properties.O12CompatibleXAdES = value;
                    WriteRegistryValue("O12CompatibleXAdES", (m_properties.O12CompatibleXAdES) ? 0 : 1); // VALUEON in .adm file is 0

                    break;
                // Signature Verification settings
                case "DoNotAllowExpiredCertificates":
                    m_properties.IgnoreExpiredCert = value;
                    WriteRegistryValue("IgnoreExpiredCert", (m_properties.IgnoreExpiredCert) ? 0: 1); // VALUEON in .adm file is 0

                    break;
                case "CheckTheXAdESPortionsOfADigitalSignature":
                    m_properties.XAdESValidationLevel = value;
                    WriteRegistryValue("XAdESValidationLevel", (m_properties.XAdESValidationLevel) ? 1 : 0);

                    break;
                // Other settings
                default:
                    break;
            }
        }

        public void OnActionDropDown(Office.IRibbonControl control, string id, int index)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "RequestedXAdESLevel":
                    m_properties.XAdESLevel = ((-1 != index) ? index : 0);
                    WriteRegistryValue("XAdESLevel", m_properties.XAdESLevel);

                    this.ribbon.InvalidateControl("RequestedXAdESLevelDescription");

                    break;
                case "MinimumXAdESLevel":
                    m_properties.MinXAdESLevel = ((-1 != index) ? index : 0);
                    WriteRegistryValue("MinXAdESLevel", m_properties.MinXAdESLevel);

                    break;
                case "TimeStampingHashingAlgorithm":
                    m_properties.TimestampHashAlg = (-1 != index) ? m_digitalSignatureHashingAlgorithm[index] : m_digitalSignatureHashingAlgorithm[0];
                    WriteRegistryValue("TimestampHashAlg", m_properties.TimestampHashAlg);

                    break;
                // Signature Verification settings
                case "SignatureVerificationLevel":
                    m_properties.VerifyVersion = ((-1 != index) ? index : 0);
                    WriteRegistryValue("VerifyVersion", m_properties.VerifyVersion); 

                    break;
                case "DigitalSignatureHashingAlgorithm":
                    m_properties.SignatureHashAlg = (-1 != index) ? m_digitalSignatureHashingAlgorithm[index] : m_digitalSignatureHashingAlgorithm[0];
                    WriteRegistryValue("SignatureHashAlg", m_properties.SignatureHashAlg);

                    break;
                default:
                    break;
            }
        }

        public string GetText(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "TimestampServerName":
                    return m_properties.TSALocation;
                case "TimestampServerTimeout":
                    return m_properties.TSATimeout.ToString();

                // Signature Verification settings
                // Other settings
                default:
                    return string.Empty;
            }
        }

        public void SetText(Office.IRibbonControl control, string value)
        {
            switch (control.Id)
            {
                // Signature Generation settings
                case "TimestampServerName":
                    m_properties.TSALocation = value;
                    WriteRegistryValue("TSALocation", m_properties.TSALocation);
                    return;
                case "TimestampServerTimeout":
                    m_properties.TSATimeout = Convert.ToInt32(value);
                    WriteRegistryValue("TSATimeout", m_properties.TSATimeout);
                    return;

                // Signature Verification settings
                // Other settings
                default:
                   break;
            }
        }
   
        #endregion

        #region Helpers

        private void Notify4Restart()
        { 
            m_newSettings = true;
            this.ribbon.InvalidateControl("RestartNotificationDescription");
        }

        private void RetrieveXAdESSettingsFromRegistry()
        {
            object value = null;

            // Signature Generation settings
            value = ReadRegistryValue("RequireOCSP");
            m_properties.RequireOCSP = (null != value) ? Convert.ToBoolean(value) : false;

            value = ReadRegistryValue("XAdESLevel");
            m_properties.XAdESLevel = (null != value) ? Convert.ToInt32(value) : 1;

            value = ReadRegistryValue("MinXAdESLevel");
            m_properties.MinXAdESLevel = (null != value) ? Convert.ToInt32(value) : 0;

            value = ReadRegistryValue("O12CompatibleXAdES");
            m_properties.O12CompatibleXAdES = (null != value) ? !Convert.ToBoolean(value) : false; // VALUEON in .adm file is 0

            value = ReadRegistryValue("TSALocation");
            m_properties.TSALocation = (null != value) ? value.ToString() : String.Empty;

            value = ReadRegistryValue("TSATimeout");
            m_properties.TSATimeout = (null != value) ? Convert.ToInt32(value) : 5;

            value = ReadRegistryValue("TimestampHashAlg");
            m_properties.TimestampHashAlg = (null != value) ? value.ToString() : String.Empty;

            // Signature Verification settings            
            value = ReadRegistryValue("VerifyVersion");
            m_properties.VerifyVersion = (null != value) ? Convert.ToInt32(value) : 1;

            value = ReadRegistryValue("SignatureHashAlg");
            m_properties.SignatureHashAlg = (null != value) ? value.ToString() : String.Empty;

            value = ReadRegistryValue("IgnoreExpiredCert");
            m_properties.IgnoreExpiredCert = (null != value) ? !Convert.ToBoolean(value) : false; // VALUEON in .adm file is 0

            value = ReadRegistryValue("XAdESValidationLevel");
            m_properties.XAdESValidationLevel = (null != value) ? Convert.ToBoolean(value) : false;

            // Other settings
        }

        private void RevertXAdESSettings2DefaultInRegistry()
        {
            try
            {
                // Open the registry key
                RegistryKey sk = Registry.CurrentUser.CreateSubKey(m_regKey);

                // Delete the optional values
                sk.DeleteValue("RequireOCSP", false);
                sk.DeleteValue("XAdESLevel", false);
                sk.DeleteValue("MinXAdESLevel", false);
                sk.DeleteValue("O12CompatibleXAdES", false);
                sk.DeleteValue("TSALocation", false);
                sk.DeleteValue("TSATimeout", false);
                sk.DeleteValue("TimestampHashAlg", false);
                sk.DeleteValue("VerifyVersion", false);
                sk.DeleteValue("SignatureHashAlg", false);
                sk.DeleteValue("IgnoreExpiredCert", false);
                sk.DeleteValue("XAdESValidationLevel", false);

                sk.Close();
            }
            catch (Exception e) { string msg = e.Message; } // msg is declared in order to suppress the warning

            Notify4Restart();
        }

        private void RevertXAdESSettings2Default()
        {
                RevertXAdESSettings2DefaultInRegistry();

                // Refresh the UI add-in to take into account the new setting
                RetrieveXAdESSettingsFromRegistry();

                this.ribbon.Invalidate();
        }

        private object ReadRegistryValue(string valueName)
        {
            object value = null;
                
            // Open the subKey as read-only
            RegistryKey sk = Registry.CurrentUser.OpenSubKey(m_regKey);

            if (null != sk)
            {
                try
                {
                    value= sk.GetValue(valueName);
                }
                catch (Exception e) { string msg = e.Message; } // msg is declared in order to suppress the warning
            }

            sk.Close();

            return value;
        }

        public bool WriteRegistryValue(string valueName, object Value)
        {
            bool ret = false;

            try
            {
                // Open the registry key
                RegistryKey sk = Registry.CurrentUser.CreateSubKey(m_regKey);

                // Save the value
                sk.SetValue(valueName, Value);
                sk.Close();

                ret = true;
            }
            catch (Exception e) { string msg = e.Message; } // msg is declared in order to suppress the warning

            if (true == ret) Notify4Restart();

            return ret;
        }

        private static string GetResourceText(string resourceName)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            string[] resourceNames = asm.GetManifestResourceNames();
            for (int i = 0; i < resourceNames.Length; ++i)
            {
                if (string.Compare(resourceName, resourceNames[i], StringComparison.OrdinalIgnoreCase) == 0)
                {
                    using (StreamReader resourceReader = new StreamReader(asm.GetManifestResourceStream(resourceNames[i])))
                    {
                        if (resourceReader != null)
                        {
                            return resourceReader.ReadToEnd();
                        }
                    }
                }
            }
            return null;
        }

        #endregion
    }
}
