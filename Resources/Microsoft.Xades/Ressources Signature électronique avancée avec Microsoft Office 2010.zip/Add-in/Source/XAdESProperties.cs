// XAdESProperties.cs
//
// Advanced Digital Signature (XAdES) Configuration Add-in for Microsoft Office Word 2010
// 2010 Microsoft France
// Published under the CECILL-B Free Software license agreement.
// (http://www.cecill.info/licences/Licence_CeCILL-B_V1-en.txt)
// 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
// THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION WITH THE USE OF THIS CODE 
// AND INFORMATION REMAINS WITH THE USER. 
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Office.Core;

namespace XAdESAddIn
{

    public class XAdESProperties
    {
        /// <summary>
        /// Requires OCSP at signature generation time
        /// </summary>
        public bool RequireOCSP
        {
            get
            {
                return GetProperty<bool>("RequireOCSP");
            }
            set
            {
                SetProperty("RequireOCSP", MsoDocProperties.msoPropertyTypeBoolean, value);
            }
        }

        /// <summary>
        /// Specifies a requested XAdES level type signature that should be created
        /// </summary>
        public int XAdESLevel
        {
            get
            {
                return GetProperty<int>("XAdESLevel");
            }
            set
            {
                SetProperty("XAdESLevel", MsoDocProperties.msoPropertyTypeNumber, value);
            }
        }

        /// <summary>
        /// Specifies a minimum XAdES level that must be applied
        /// </summary>
        public int MinXAdESLevel
        {
            get
            {
                return GetProperty<int>("MinXAdESLevel");
            }
            set
            {
                SetProperty("MinXAdESLevel", MsoDocProperties.msoPropertyTypeNumber, value);
            }
        }

        /// <summary>
        /// Do not include XAdES reference object in the manifest
        /// </summary>
        public bool O12CompatibleXAdES
        {
            get
            {
                return GetProperty<bool>("O12CompatibleXAdES");
            }
            set
            {
                SetProperty("O12CompatibleXAdES", MsoDocProperties.msoPropertyTypeBoolean, value);
            }
        }

        /// <summary>
        /// Specifies the URL of the time stamp server that will be used to create timestamps
        /// </summary>
        public string TSALocation
        {
            get
            {
                return GetProperty<string>("TSALocation");
            }
            set
            {
                SetProperty("TSALocation", MsoDocProperties.msoPropertyTypeString, value);
            }
        }

        /// <summary>
        /// Specifies the timestamp server timeout
        /// </summary>
        public int TSATimeout
        {
            get
            {
                return GetProperty<int>("TSATimeout");
            }
            set
            {
                SetProperty("TSATimeout", MsoDocProperties.msoPropertyTypeNumber, value);
            }
        }

        /// <summary>
        /// Specifies the time stamping hashing algorithm
        /// </summary>
        public string TimestampHashAlg
        {
            get
            {
                return GetProperty<string>("TimestampHashAlg");
            }
            set
            {
                SetProperty("TimestampHashAlg", MsoDocProperties.msoPropertyTypeString, value);
            }
        }

        // Signature Verification settings

        /// <summary>
        /// Specifies the signature verification level
        /// </summary>
        public int VerifyVersion
        {
            get
            {
                return GetProperty<int>("VerifyVersion");
            }
            set
            {
                SetProperty("VerifyVersion", MsoDocProperties.msoPropertyTypeNumber, value);
            }
        }

        /// <summary>
        /// Specifies the digital signature hashing algorithm
        /// </summary>
        public string SignatureHashAlg
        {
            get
            {
                return GetProperty<string>("SignatureHashAlg");
            }
            set
            {
                SetProperty("SignatureHashAlg", MsoDocProperties.msoPropertyTypeString, value);
            }
        }

        /// <summary>
        /// Do not allow expired certificates when validating signatures
        /// </summary>
        public bool IgnoreExpiredCert
        {
            get
            {
                return GetProperty<bool>("IgnoreExpiredCert");
            }
            set
            {
                SetProperty("IgnoreExpiredCert", MsoDocProperties.msoPropertyTypeBoolean, value);
            }
        }

        /// <summary>
        /// Checks or not the XAdES portions of a digital signature
        /// </summary>
        public bool XAdESValidationLevel
        {
            get
            {
                return GetProperty<bool>("XAdESValidationLevel");
            }
            set
            {
                SetProperty("XAdESValidationLevel", MsoDocProperties.msoPropertyTypeBoolean, value);
            }
        }

        private T GetProperty<T>(string propertyName)
        {
            DocumentProperty property = FindProperty(propertyName);
            if (property == null)
                return default(T);
            else
                return (T)property.Value;
        }

        private void SetProperty(string propertyName, MsoDocProperties propertyType, object value)
        {
            DocumentProperty property = FindProperty(propertyName);
            if (property == null)
                AddProperty(propertyName, propertyType, value);
            else
                property.Value = value;
        }

        private DocumentProperty FindProperty(string propertyName)
        {
            DocumentProperties properties = (DocumentProperties)
                Globals.ThisAddIn.Application.ActiveDocument.CustomDocumentProperties;
            return properties.Cast<DocumentProperty>().FirstOrDefault(n => n.Name == propertyName);
        }

        private void AddProperty(string propertyName, MsoDocProperties propertyType, object value)
        {   
            DocumentProperties properties = (DocumentProperties)
                Globals.ThisAddIn.Application.ActiveDocument.CustomDocumentProperties;
            properties.Add(propertyName, false, propertyType, value);
        }
    }
}